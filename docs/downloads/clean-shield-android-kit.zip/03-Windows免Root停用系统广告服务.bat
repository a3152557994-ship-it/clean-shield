@echo off
echo === CleanShield Android Safe Ad-Service Disabler (Windows) ===
where adb >nul 2>nul
if %errorlevel% neq 0 (
  echo [!] Please extract Android platform-tools (adb.exe) into this folder first.
  pause
  exit /b 1
)
adb devices
for %%p in (
  com.miui.systemAdSolution
  com.miui.analytics
  com.xiaomi.ab
  com.oppo.ads
  com.nearme.statistics.rom
  com.vivo.magazine
) do (
  echo Disabling %%p ...
  adb shell pm disable-user --user 0 %%p
)
echo === Completed! Reboot your phone once. ===
pause
