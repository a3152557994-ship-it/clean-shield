#!/usr/bin/env bash
# CleanShield Safe Android System Ad Service Disabler (No-Root ADB)
# Only disables well-known vendor ad-delivery services; 100% reversible via `pm enable`.
set -u

echo "=== CleanShield Android Safe Ad-Service Disabler ==="
if ! command -v adb >/dev/null 2>&1; then
  echo "[!] adb not found. Install Android Platform Tools first."
  exit 1
fi

adb devices
AD_PACKAGES=(
  "com.miui.systemAdSolution"
  "com.miui.analytics"
  "com.xiaomi.ab"
  "com.huawei.intelligent"
  "com.oppo.ads"
  "com.nearme.statistics.rom"
  "com.vivo.magazine"
)

for pkg in "${AD_PACKAGES[@]}"; do
  echo "-> Attempting safe disable for $pkg ..."
  adb shell pm disable-user --user 0 "$pkg" 2>/dev/null || true
done

echo "=== Done! Reboot phone once for clean state. To restore any package: adb shell pm enable <pkg> ==="
